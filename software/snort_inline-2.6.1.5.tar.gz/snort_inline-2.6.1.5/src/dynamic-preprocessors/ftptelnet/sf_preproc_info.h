#ifndef SF_PREPROC_INFO_H
#define SF_PREPROC_INFO_H

#define MAJOR_VERSION   1
#define MINOR_VERSION   0
#define BUILD_VERSION   10
#define PREPROC_NAME    "SF_FTPTELNET"

#define DYNAMIC_PREPROC_SETUP SetupFTPTelnet
extern void SetupFTPTelnet();

#endif /* SF_PREPROC_INFO_H */
