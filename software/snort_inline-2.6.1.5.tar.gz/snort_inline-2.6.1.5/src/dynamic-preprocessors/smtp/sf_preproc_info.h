#ifndef SF_PREPROC_INFO_H
#define SF_PREPROC_INFO_H

#define MAJOR_VERSION   1
#define MINOR_VERSION   0
#define BUILD_VERSION   7
#define PREPROC_NAME    "SF_SMTP"

#define DYNAMIC_PREPROC_SETUP SetupSMTP
extern void SetupSMTP();

#endif /* SF_PREPROC_INFO_H */
