#ifndef _FLOW_CONFIG_H
#define _FLOW_CONFIG_H
typedef struct FlowConfig
{
    int memcap;
}

#endif /* _FLOW_CONFIG_H */
