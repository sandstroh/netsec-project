/*
**  @file       spp_psng.h
**
**  @author     Daniel Roelker <droelker@sourcefire.com>
**
**  @brief      APIs for Snort Portscan
*/
#ifndef __SPP_PSNG_H__
#define __SPP_PSNG_H__

void SetupPsng(void);

#endif
