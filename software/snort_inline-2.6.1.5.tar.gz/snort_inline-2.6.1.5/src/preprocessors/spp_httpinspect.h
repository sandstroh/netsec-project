/**
**  @file spp_httpinspect.h
**
**  @author Daniel Roelker <droelker@sourcefire.com>
*/
#ifndef __SPP_HTTPINSPECT_H__
#define __SPP_HTTPINSPECT_H__

void SetupHttpInspect();

#endif
