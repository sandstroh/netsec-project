#ifndef SNORT_STREAM4_UDP_H_
#define SNORT_STREAM4_UDP_H_

void Stream4ProcessUdp(Packet *p);
void Stream4UdpConfigure();

#endif /* SNORT_STREAM4_UDP_H_ */

